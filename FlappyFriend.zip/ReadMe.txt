Hiya!
If you're reading this, then you probably picked up my game, Flappy Friend!

Just a note, I do not own the concept of flappy bird games, and all the art was custom made, along with the code

Feel free to share this game with friends and family, but please don't claim ownership, I worked way too hard to be stolen from.

-Red